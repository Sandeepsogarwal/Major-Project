from setuptools import find_packages, setup

setup(
    name="Language-Identification-Using-CNN",
    version="1.0",
    author="Aravind S",
    author_email="cloud@ineuron.ai",
    packages=find_packages(),
    install_requires=[],
)